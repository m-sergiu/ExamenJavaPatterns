# GProject_DesignPatterns
Muntean Sergiu